Tesseract OCR 5.5.4 for macOS (arm64 + x86_64), downloaded by HyperZebra to read the text
in pictures. HyperZebra runs it as a separate program; it is not part of HyperZebra.

Built from the unmodified upstream sources, statically linked:
  Tesseract 5.5.4  https://github.com/tesseract-ocr/tesseract  Apache License 2.0
  Leptonica 1.87.0  https://github.com/DanBloomberg/leptonica  BSD 2-Clause License
  libpng 1.6.59        https://github.com/pnggroup/libpng       PNG Reference Library License v2
zlib and the C++ library are the ones of macOS. The licenses are in the licenses folder.
Language data (traineddata) is downloaded separately from https://github.com/tesseract-ocr/tessdata_fast
(Apache License 2.0).
Build script: tools/release/build-tesseract-mac.sh in https://github.com/pgostation/HyperZebra
